#include<stdio.h>
int main()
{
    int a,b;
    printf("keydown a,b");
    scanf("%d%d",&a,&b);
    printf("a^2+b^2=%d",a*a+b*b);
    return 0;
}
